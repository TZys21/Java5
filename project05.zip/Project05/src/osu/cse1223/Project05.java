/*
 * 
 * 
 * @Author Tyler Zysberg
 */

package osu.cse1223;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Project05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f = new File("paths.txt");
		Scanner in = new Scanner(System.in);
//		try {
//		in = new Scanner(f);
		System.out.print("Enter a file name with paths: ");
		String fileName = in.nextLine();
//		String fileName = "paths.txt";
		Map<String,List<Path>> read = readPaths(fileName);
		displayAdjacencyList(read);
		System.out.println(" ");
		System.out.print("Enter a start city (empty line to quit): ");
		String start = in.nextLine();
		System.out.println(" ");
		//while (start.length() > 0) {
			findDistances(start, read);
			displayShortest(start,
					findDistances(start, readPaths(fileName)));
			System.out.println(" ");
			System.out.print("Enter a start city(empty line to quit): ");
			start = in.next();
			System.out.println(" ");
		//}
		System.out.println("Goodbye!");
		in.close();
	}

	public static Map<String, List<Path>> readPaths(String fname) {
		Map<String, List<Path>> adj_List = new HashMap<String, List<Path>>();
		String test="";
		try {
			File file = new File(fname);
			Scanner list = new Scanner(file);
			while (list.hasNext()) {
				test = list.nextLine();
				if(!test.equals("")){
					
					String tokens[] = test.split(",");

					double distance = Double.parseDouble(tokens[2]);

					Path to = new Path(tokens[1], distance);
					Path from = new Path(tokens[0], distance);

					if (!adj_List.containsKey(tokens[0])) {
						adj_List.put(tokens[0], new LinkedList<Path>());
					}
					if (!adj_List.containsKey(tokens[1])) {
						adj_List.put(tokens[1], new LinkedList<Path>());
					}
					adj_List.get(tokens[0]).add(to);
					adj_List.get(tokens[1]).add(from);
				}
			}
			list.close();
		} catch (IOException e) {
			System.out.println(test+"There was an error reading from " + fname);
		}
		return adj_List;
	}

	public static Map<String, Double> findDistances(String start,
			Map<String, List<Path>> adj_List) {
		
		Map<String, Double> shortestDistances = new HashMap<String, Double>();
		//maps names to final path costs
		
		PriorityQueue<Path> pq = new PriorityQueue<Path>();
		//prioritizes paths in order of path cost
		
		Path x = new Path(start, 0.0);
		pq.add(x);
		while (!pq.isEmpty()){
			Path current = pq.remove();
			if (shortestDistances.get(current) == null){
				double d = current.getCost();
				String dest = current.getEndpoint();
				shortestDistances.put(dest, d);
			
				for (String y : adj_List.keySet()){
					List<Path> list = adj_List.get(y);
					for (Path p : list){
						if (p.getEndpoint().equals(start)){
							Path newPath = new Path(y , d + p.getCost());
							pq.add(newPath);
						}
					}

				}
			}

		}
		

		return shortestDistances;
	}

	public static void displayShortest(String start,
			Map<String, Double> shortest) {
		System.out.println("Distances from " + start + " to each city:");
		System.out.println(" ");
		System.out.println("Dest. City     Distance");
		System.out.println("-------------- --------");

		Iterator<Entry<String, Double>> iter = shortest.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<String, Double> currentKey = iter.next();
			System.out.printf("%-14s %8.2f\n", currentKey.getKey(),
					currentKey.getValue());
		}
	}

	public static void displayAdjacencyList(Map<String, List<Path>> adj_List) {
		System.out.println("Start City     Paths ");
		System.out.println("-------------- ------------------------------");
		Iterator<Entry<String, List<Path>>> iter = adj_List.entrySet()
				.iterator();
		while (iter.hasNext()) {
			Entry<String, List<Path>> currentKey = iter.next();
			System.out.printf("%-14s", currentKey.getKey());
			Iterator<Path> it2 = currentKey.getValue().iterator();
			while(it2.hasNext()){
				Path at=it2.next();
				System.out.print("(" + at.getEndpoint() +  ":" + at.getCost()+")" );
				if(it2.hasNext()){
					System.out.print(", ");
				}
			}
			System.out.println();

		}
	}




	}


